package mx.edu.utez.extra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExtraApplicationTests {

	@Test
	void contextLoads() {
	}

}
